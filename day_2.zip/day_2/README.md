# akademyAI_lectures
- Week 1
- Week 2
